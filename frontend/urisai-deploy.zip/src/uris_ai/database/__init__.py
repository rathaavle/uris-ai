"""Database performance optimization utilities."""
