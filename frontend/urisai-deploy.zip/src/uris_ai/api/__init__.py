"""FastAPI application module."""
